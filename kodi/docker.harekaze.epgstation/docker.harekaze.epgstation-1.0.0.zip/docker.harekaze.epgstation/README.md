EPGStation addon for Kodi on LibreELEC
---
![icon](icon@2x.png)

EPGStation docker service running on LibreELEC

## License

[GPL 3.0](LICENSE)
